import sys
sys.path.insert(0, '../')
from planet_wars import issue_order


# ATTACK
# issue order to attack cheapest enemy planet from closest owned planet AS LONG AS:
#   1. no friendly ships on the way
#   2. owned planet can afford it
def attack_lowest_from_closest(state):

    # untargeted enemy planets sorted (low-high, num_ships)
    enemy_planets = [planet for planet in state.enemy_planets()
                      if (not any(fleet.destination_planet == planet.ID for fleet in state.my_fleets()))]
    if not enemy_planets:
        return False
    target_planet = min(enemy_planets, key=lambda p: p.num_ships)

    # my planets sorted (low-high, distance from target)
    my_planets = iter(sorted(state.my_planets(), key=lambda p: state.distance(target_planet.ID, p.ID)))

    # EDIT: ONLY LET UNTARGETED PLANETS ATTACK/DONATE
    my_planets = [planet for planet in state.my_planets()
                      if not any(fleet.destination_planet == planet.ID for fleet in state.enemy_fleets())]
    my_planets = iter(sorted(my_planets, key=lambda p: state.distance(target_planet.ID, p.ID)))

    try:
        my_planet = next(my_planets)

        while True:
            # compute cost for enemy planet
            required_ships = target_planet.num_ships + \
                                 state.distance(my_planet.ID, target_planet.ID) * target_planet.growth_rate + 1

            # find closest planet that can afford to take
            if my_planet.num_ships > required_ships:
                return issue_order(state, my_planet.ID, target_planet.ID, required_ships)
            else:
                my_planet = next(my_planets)

    except StopIteration:
        return False

# ATTACK
# issue order to attack cheapest enemy planet from closest owned planet AS LONG AS:
#   1. no friendly ships on the way
#   2. owned planet can afford it
def attack_lowest_from_closest2(state):

    # untargeted enemy planets sorted (low-high, num_ships)
    enemy_planets = [planet for planet in state.enemy_planets()]
    if not enemy_planets:
        return False
    target_planet = min(enemy_planets, key=lambda p: p.num_ships)

    # my planets sorted (low-high, distance from target)
    my_planets = iter(sorted(state.my_planets(), key=lambda p: state.distance(target_planet.ID, p.ID)))

    # EDIT: ONLY LET UNTARGETED PLANETS ATTACK/DONATE
    my_planets = [planet for planet in state.my_planets()
                      if not any(fleet.destination_planet == planet.ID for fleet in state.enemy_fleets())]
    my_planets = iter(sorted(my_planets, key=lambda p: state.distance(target_planet.ID, p.ID)))

    try:
        my_planet = next(my_planets)

        while True:
            # compute cost for enemy planet
            required_ships = (target_planet.num_ships + \
                                 state.distance(my_planet.ID, target_planet.ID) * target_planet.growth_rate)/3 + 1

            # find closest planet that can afford to take
            if my_planet.num_ships > required_ships:
                return issue_order(state, my_planet.ID, target_planet.ID, required_ships)
            else:
                my_planet = next(my_planets)

    except StopIteration:
        return False



# UNCONTESTED SPREAD
# issue order to spread to cheapest neutral planet from closest owned planet AS LONG AS:
#   1. no friendly ships on the way
#   2. no enemy ships on the way
#   3. owned planet can afford it
def spread_lowest_from_closest_untargeted(state):

    # untargeted neutral planets sorted (low-high, num_ships)
    neutral_planets = [planet for planet in state.neutral_planets()
                      if (not any(fleet.destination_planet == planet.ID for fleet in state.my_fleets())
                      and not any(fleet.destination_planet == planet.ID for fleet in state.enemy_fleets()))]
    if not neutral_planets:
        return False
    target_planet = min(neutral_planets, key=lambda p: p.num_ships)

    # my planets sorted (low-high, distance from target)
    my_planets = iter(sorted(state.my_planets(), key=lambda p: state.distance(target_planet.ID, p.ID)))

    # EDIT: ONLY LET UNTARGETED PLANETS ATTACK/DONATE
    my_planets = [planet for planet in state.my_planets()
                      if not any(fleet.destination_planet == planet.ID for fleet in state.enemy_fleets())]
    my_planets = iter(sorted(my_planets, key=lambda p: state.distance(target_planet.ID, p.ID)))

    try:

        my_planet = next(my_planets)

        while True:
            # compute cost for neutral planet
            required_ships = target_planet.num_ships + 1

            # find closest planet that can afford to take
            if my_planet.num_ships > required_ships:
                return issue_order(state, my_planet.ID, target_planet.ID, required_ships)
            else:
                my_planet = next(my_planets)

    except StopIteration:
        return False


# SPREAD
def spread_lowest_from_closest_untargeted2(state):

    # magic sweet spot :")
    distance_scalar = 5

    # untargeted neutral planets sorted (low-high, num_ships)
    neutral_planets = [planet for planet in state.neutral_planets()
                      if (not any(fleet.destination_planet == planet.ID for fleet in state.my_fleets())
                      and not any(fleet.destination_planet == planet.ID for fleet in state.enemy_fleets()))]
    # ======================
    # MOVE THIS TO CHECKS.PY
    # ======================
    if not neutral_planets:
        return False

    # find my_planet with highest num_ships
    my_planets = iter(sorted(state.my_planets(), key=lambda p: p.num_ships, reverse=True))
    my_planet = next(my_planets)

    # find target_planet with lowest num_ships + distance from my_planet
    target_planets = iter(sorted(neutral_planets, key=lambda p: p.num_ships + distance_scalar*state.distance(my_planet.ID, p.ID)))
    target_planet = next(target_planets)

    # compute ships required
    required_ships = target_planet.num_ships+1

    # send ships if my_planet has enough
    if my_planet.num_ships > required_ships:
        return issue_order(state, my_planet.ID, target_planet.ID, required_ships)
    else:
        return False



# ACTIVE DEFEND
def defend_from_closest(state):

    # get planet under attack
    targeted_planets = [planet for planet in state.my_planets()
                      # no friendly fleet otw
                      if (not any(fleet.destination_planet == planet.ID for fleet in state.my_fleets())
                      # enemy fleet otw
                      and any(fleet.destination_planet == planet.ID for fleet in state.enemy_fleets()))]
    if not targeted_planets:
        return False
    target_planet = min(targeted_planets, key=lambda p: p.num_ships) # min???

    # get fleet performing attack
    enemy_fleet = next((fleet for fleet in state.enemy_fleets() if fleet.destination_planet == target_planet.ID), None)
    fleet_distance = enemy_fleet.turns_remaining # removal

    # TEMP
    ships_count_by_arrival = target_planet.num_ships + fleet_distance * target_planet.growth_rate

    # get planet under attack
    my_planets = [planet for planet in state.my_planets()
                      if (not any(fleet.destination_planet == planet.ID for fleet in state.my_fleets())
                      and not any(fleet.destination_planet == planet.ID for fleet in state.enemy_fleets())
                      and state.distance(planet.ID, target_planet.ID) <= fleet_distance)]

    # my planets sorted (low-high, distance from target)
    my_planets = iter(sorted(my_planets, key=lambda p: state.distance(target_planet.ID, p.ID)))

    try:
        my_planet = next(my_planets)

        while True:
            # compute cost for neutral planet
            required_ships = enemy_fleet.num_ships - ships_count_by_arrival + 1
            if not required_ships > 0:
                return False


            # find closest planet that can afford to take
            if my_planet.num_ships > required_ships:
                return issue_order(state, my_planet.ID, target_planet.ID, required_ships)
            else:
                my_planet = next(my_planets)

    except StopIteration:
        return False




def if_neutral_planet_available(state):
    return any(state.neutral_planets())

'''def if_neutral_untargeted_available(state):
	neutral_planets = [planet for planet in state.neutral_planets()
                      if (not any(fleet.destination_planet == planet.ID for fleet in state.my_fleets())
                      and not any(fleet.destination_planet == planet.ID for fleet in state.enemy_fleets()))]
    return len(neutral_planets)>0
'''

def if_enemy_planet_available(state):
	return any(state.enemy_planets())

def have_largest_fleet(state):
    return sum(planet.num_ships for planet in state.my_planets()) \
             + sum(fleet.num_ships for fleet in state.my_fleets()) \
           > sum(planet.num_ships for planet in state.enemy_planets()) \
             + sum(fleet.num_ships for fleet in state.enemy_fleets())

# returns whether enemy has fleets deployed
def enemy_fleet_deployed(state):
	return len(state.enemy_fleets())>0

# returns true if enemy's smallest planet is larger than our biggest planet
def unbeatable(state):
    en = min(state.enemy_planets(), key=lambda p: p.num_ships, default=None)
    me = max(state.my_planets(), key=lambda p: p.num_ships, default=None)
    if en == None or me == None:
        return False
    return en.num_ships > me.num_ships

